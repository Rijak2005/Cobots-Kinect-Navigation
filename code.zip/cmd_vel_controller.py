from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Optional, Tuple

from robot_tracker import RobotPose2D

# Deadzones (confirmed)
DZ_X = 6553
DZ_Y = 12553
DZ_YAW = 9553

AXIS_MIN = -32767
AXIS_MAX = 32767


def clamp_axis(v: int) -> int:
    return max(AXIS_MIN, min(AXIS_MAX, int(v)))


def wrap_angle(rad: float) -> float:
    return (rad + math.pi) % (2.0 * math.pi) - math.pi


def world_to_body(vx_w: float, vy_w: float, heading_rad: float) -> tuple[float, float]:
    """
    Convert WORLD vector -> BODY components.

    heading_rad: robot heading in WORLD; 0 means robot faces +WORLD_X
    BODY:
      +x forward
      +y right (your statement: +axis_y moves robot to the right)
    """
    c = math.cos(heading_rad)
    s = math.sin(heading_rad)
    vx_b = c * vx_w + s * vy_w
    vy_b = -s * vx_w + c * vy_w
    return vx_b, vy_b


@dataclass
class AxisGains:
    # ======== USER KNOBS ========
    # Forward/back must be > 6553
    axis_fwd_fast: int = 9000
    axis_fwd_near: int = 7000  # minimal slow speed (just above deadzone)

    # Lateral must be > 12553
    axis_lat_mag: int = 16000

    # Yaw: instead of a single bang-bang value, use min/max + proportional mapping
    axis_yaw_min: int = 10050  # must be > DZ_YAW; small safe turn
    axis_yaw_max: int = 11000  # cap for larger yaw errors

    # Degrees of error that corresponds to reaching axis_yaw_max
    yaw_full_err_deg: float = 35.0

    # Require holding inside tolerance for these ticks (helps stop overshoot)
    stable_turn_ticks: int = 4
    # ============================

    # tolerances
    axis_tol_m: float = 0.03
    arrive_radius_m: float = 0.07
    stable_reach_ticks: int = 4

    # slow down zones (meters)
    slow_y_m: float = 0.25
    slow_x_m: float = 0.25

    # heading alignment at approach
    turn_tol_deg: float = 8.0

    # bump above deadzone if needed
    bump_over_deadzone: bool = True


@dataclass
class AxisOut:
    ax: int
    ay: int
    az: int
    reached: bool
    phase: str
    status: str


class AxisStepController:
    """
    Translation to approach (NO yaw):
      - reduce WORLD Y error first, then WORLD X error
      - command is converted into body (ax, ay) using heading.

    Yaw:
      - proportional yaw near tolerance + settle-hold to avoid overshoot.

    lat_sign:
      - If your grid Y is flipped, set lat_sign = -1 (you confirmed this works).
    """

    def __init__(self, g: AxisGains) -> None:
        self.g = g
        self.reset()

    def reset(self) -> None:
        self._reach_streak = 0
        self._last_goal: Optional[Tuple[float, float]] = None
        self._phase_axis = "Y"  # "Y" then "X"
        self._lat_sign: int = -1
        self._turn_streak = 0  # for yaw settle-hold

    def set_lateral_sign(self, lat_sign: int) -> None:
        self._lat_sign = +1 if lat_sign >= 0 else -1

    def get_lateral_sign(self) -> int:
        return self._lat_sign

    def _new_goal_if_needed(self, goal: Tuple[float, float]) -> None:
        if self._last_goal != goal:
            self._last_goal = goal
            self._phase_axis = "Y"
            self._reach_streak = 0
            self._turn_streak = 0

    def _reached(self, robot: RobotPose2D, goal: Tuple[float, float]) -> bool:
        dx = goal[0] - robot.x
        dy = goal[1] - robot.y
        dist = math.hypot(dx, dy)
        if dist <= self.g.arrive_radius_m:
            self._reach_streak += 1
        else:
            self._reach_streak = 0
        return self._reach_streak >= self.g.stable_reach_ticks

    def _bump(self, v: int, dead: int) -> int:
        if v == 0:
            return 0
        if not self.g.bump_over_deadzone:
            return v
        if abs(v) <= dead:
            return (dead + 1) if v > 0 else -(dead + 1)
        return v

    def _pick_fwd_mag(self, err_m: float, slow_m: float) -> int:
        return self.g.axis_fwd_near if abs(err_m) < slow_m else self.g.axis_fwd_fast

    def _dir_world_to_axes(
        self, vx_w: float, vy_w: float, heading: float, fwd_mag: int, lat_mag: int
    ) -> tuple[int, int]:
        vx_b, vy_b = world_to_body(vx_w, vy_w, heading)

        m = max(abs(vx_b), abs(vy_b))
        if m < 1e-9:
            return 0, 0
        nx = vx_b / m
        ny = vy_b / m

        ax = int(round(nx * fwd_mag))
        ay = int(round(ny * lat_mag))

        # apply lateral sign fix
        ay = int(self._lat_sign * ay)

        ax = clamp_axis(ax)
        ay = clamp_axis(ay)

        ax = self._bump(ax, DZ_X)
        ay = self._bump(ay, DZ_Y)
        return ax, ay

    # -------- translation-only travel (NO yaw) --------
    def move_to_point_y_then_x(self, robot: RobotPose2D, goal: Tuple[float, float]) -> AxisOut:
        self._new_goal_if_needed(goal)

        ex = goal[0] - robot.x
        ey = goal[1] - robot.y

        if self._reached(robot, goal):
            return AxisOut(0, 0, 0, True, "REACHED", "Reached (stable)")

        # 1) WORLD Y
        if self._phase_axis == "Y":
            if abs(ey) <= self.g.axis_tol_m:
                self._phase_axis = "X"
            else:
                vy_w = 1.0 if ey > 0 else -1.0
                fwd_mag = self._pick_fwd_mag(ey, self.g.slow_y_m)
                ax, ay = self._dir_world_to_axes(
                    0.0, vy_w, robot.heading, fwd_mag=fwd_mag, lat_mag=self.g.axis_lat_mag
                )
                return AxisOut(ax, ay, 0, False, "MOVE_WY", f"Reduce world-Y ey={ey:+.3f}m fwd_mag={fwd_mag}")

        # 2) WORLD X
        if abs(ex) > self.g.axis_tol_m:
            vx_w = 1.0 if ex > 0 else -1.0
            fwd_mag = self._pick_fwd_mag(ex, self.g.slow_x_m)
            ax, ay = self._dir_world_to_axes(
                vx_w, 0.0, robot.heading, fwd_mag=fwd_mag, lat_mag=self.g.axis_lat_mag
            )
            return AxisOut(ax, ay, 0, False, "MOVE_WX", f"Reduce world-X ex={ex:+.3f}m fwd_mag={fwd_mag}")

        return AxisOut(0, 0, 0, False, "HOLD", "Inside axis tolerance, holding")

    # -------- rotate gently with settle-hold (prevents overshoot) --------
    def turn_to_face(self, robot: RobotPose2D, face_goal: Tuple[float, float]) -> AxisOut:
        dx = face_goal[0] - robot.x
        dy = face_goal[1] - robot.y
        desired = math.atan2(dy, dx)
        err = wrap_angle(desired - robot.heading)

        tol = math.radians(self.g.turn_tol_deg)
        err_deg = abs(math.degrees(err))

        # inside tolerance: HOLD (0 yaw) for a few ticks so robot stops rotating
        if abs(err) <= tol:
            self._turn_streak += 1
            reached = self._turn_streak >= self.g.stable_turn_ticks
            return AxisOut(
                0, 0, 0, reached, "TURN_HOLD",
                f"Within tol. hold {self._turn_streak}/{self.g.stable_turn_ticks} err={math.degrees(err):+.1f}°"
            )

        # outside tolerance: reset settle streak
        self._turn_streak = 0

        # proportional yaw magnitude:
        # small err -> axis_yaw_min, large err -> axis_yaw_max
        frac = min(1.0, err_deg / max(1e-6, float(self.g.yaw_full_err_deg)))
        mag = int(round(self.g.axis_yaw_min + frac * (self.g.axis_yaw_max - self.g.axis_yaw_min)))

        # sign from error each tick (lets it correct if it overshoots)
        az = mag if err > 0 else -mag
        az = clamp_axis(az)

        # ensure above yaw deadzone
        if abs(az) <= DZ_YAW:
            az = (DZ_YAW + 1) if az > 0 else -(DZ_YAW + 1)

        return AxisOut(0, 0, az, False, "TURN", f"Turn err={math.degrees(err):+.1f}° mag={mag}")

    # -------- final approach: forward/back along current heading (NO strafe, NO yaw) --------
    def forward_to_point(self, robot: RobotPose2D, goal: Tuple[float, float]) -> AxisOut:
        """
        Drive along the robot's forward axis toward the goal.
        Direction is decided by projecting goal vector onto heading.
        This fixes "walking backwards after rotating to face home".
        """
        if self._reached(robot, goal):
            return AxisOut(0, 0, 0, True, "REACHED", "Reached (stable)")

        dx = goal[0] - robot.x
        dy = goal[1] - robot.y

        # projection onto heading: >0 means goal is in front
        c = math.cos(robot.heading)
        s = math.sin(robot.heading)
        along = dx * c + dy * s

        mag = self._pick_fwd_mag(along, slow_m=0.35)
        ax = mag if along >= 0 else -mag
        ax = self._bump(clamp_axis(ax), DZ_X)

        dist = math.hypot(dx, dy)
        return AxisOut(ax, 0, 0, False, "FINAL_FWD", f"Along heading={along:+.3f}m dist={dist:.2f}m mag={mag}")

    # -------- reverse carefully (used for back-to-approach) --------
    def backward_to_point(self, robot: RobotPose2D, goal: Tuple[float, float]) -> AxisOut:
        """
        Reverse slowly (no yaw, no strafe) until we reach goal.
        Uses NEAR speed always (controlled).
        """
        if self._reached(robot, goal):
            return AxisOut(0, 0, 0, True, "REACHED", "Reached (stable)")

        mag = int(self.g.axis_fwd_near)
        ax = -mag
        ax = self._bump(clamp_axis(ax), DZ_X)

        dx = goal[0] - robot.x
        dy = goal[1] - robot.y
        dist = math.hypot(dx, dy)
        return AxisOut(ax, 0, 0, False, "BACK", f"Backward only mag={mag} dist={dist:.2f}m")

    # deterministic 180° turn helper if you ever need it
    def turn_to_heading(self, robot: RobotPose2D, desired_heading_rad: float) -> AxisOut:
        dummy_goal = (robot.x + math.cos(desired_heading_rad), robot.y + math.sin(desired_heading_rad))
        return self.turn_to_face(robot, dummy_goal)